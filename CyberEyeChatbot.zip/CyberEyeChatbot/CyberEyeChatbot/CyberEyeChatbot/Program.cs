﻿using System;
using System.Collections.Generic;
using System.Media;
using System.Threading;

class CyberEyeChatbot
{
    static string userName = "";
    static string userInterest = "";
    static Dictionary<string, List<string>> phishingTips = new Dictionary<string, List<string>>()
    {
        { "phishing", new List<string> {
            "Be cautious of emails that ask for personal information. Always verify the sender.",
            "Scammers often impersonate trusted sources. Look out for urgent language or misspelled domains.",
            "Don't click on suspicious links. Hover over them to preview the URL first.",
            "Use multi-factor authentication to add an extra layer of security against phishing."
        }}
    };

    static Dictionary<string, List<string>> passwordTips = new Dictionary<string, List<string>>()
    {
        { "password", new List<string> {
            "Use a combination of upper/lowercase letters, numbers, and symbols in your passwords.",
            "Avoid reusing passwords across multiple accounts.",
            "Consider using a password manager to generate and store secure passwords.",
            "Update your passwords regularly and never share them with anyone."
        }}
    };

    static void Main()
    {
        PlayVoiceGreeting();
        DisplayAsciiLogo();

        Console.Write("Please enter your name: ");
        userName = Console.ReadLine();

        Console.Write($"Hi {userName}, what cybersecurity topic interests you most (e.g. phishing, privacy, passwords)? ");
        userInterest = Console.ReadLine().ToLower();

        Console.WriteLine($"Awesome! I’ll remember that you're interested in {userInterest}. Let's start!\n");

        StartChatbot();
    }

    static void PlayVoiceGreeting()
    {
        try
        {
            string filePath = "greeting.wav";
            if (System.IO.File.Exists(filePath))
            {
                SoundPlayer player = new SoundPlayer(filePath);
                player.PlaySync();
            }
            else
            {
                Console.WriteLine("Warning: greeting.wav file not found.");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Audio playback error: {ex.Message}");
        }
    }

    static void DisplayAsciiLogo()
    {
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine(@"
 ██████╗██╗   ██╗███████╗███████╗
██╔════╝██║   ██║██╔════╝██╔════╝
██║     ██║   ██║█████╗  ███████╗
██║     ██║   ██║██╔══╝  ╚════██║
╚██████╗╚██████╔╝███████╗███████║
 ╚═════╝ ╚═════╝ ╚══════╝╚══════╝
      Cyber Eye - Secure the Future
");
        Console.ResetColor();
    }

    static void StartChatbot()
    {
        Random rand = new Random();

        while (true)
        {
            Console.Write("\nYou: ");
            string input = Console.ReadLine().ToLower();

            if (input == "exit")
            {
                TypingEffect($"Goodbye {userName}, stay safe online!");
                break;
            }

            // Sentiment detection
            if (input.Contains("worried") || input.Contains("scared"))
            {
                TypingEffect("It's okay to feel worried. Cybersecurity can be complex, but I'm here to help you step by step.");
                continue;
            }
            else if (input.Contains("frustrated") || input.Contains("annoyed"))
            {
                TypingEffect("I understand your frustration. Let’s work through your concerns together.");
                continue;
            }

            // Keyword responses
            if (input.Contains("phishing"))
            {
                var responses = phishingTips["phishing"];
                TypingEffect($"Here's a phishing tip for you, {userName}: {responses[rand.Next(responses.Count)]}");
            }
            else if (input.Contains("password"))
            {
                var responses = passwordTips["password"];
                TypingEffect($"Hi {userName}, here’s a password safety tip: {responses[rand.Next(responses.Count)]}");
            }
            else if (input.Contains("privacy"))
            {
                TypingEffect($"Since you're interested in privacy, {userName}, be sure to review your app permissions and avoid oversharing online.");
            }
            else if (input.Contains("how are you"))
            {
                TypingEffect("I'm functioning securely and ready to assist you, thank you!");
            }
            else if (input.Contains("remember me"))
            {
                TypingEffect($"Of course! You're {userName} and you're interested in {userInterest}.");
            }
            else if (input.Contains("what can i ask"))
            {
                TypingEffect("You can ask me about phishing, password security, privacy, or any general cybersecurity questions.");
            }
            else
            {
                TypingEffect("Hmm, I didn't catch that. Could you try asking differently?");
            }
        }
    }

    static void TypingEffect(string message)
    {
        foreach (char c in message)
        {
            Console.Write(c);
            Thread.Sleep(25);
        }
        Console.WriteLine();
    }
}
