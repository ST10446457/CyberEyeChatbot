﻿using System;
using System.Collections.Generic;
using System.Media;
using System.Threading;

class CyberEyeChatbot
{
    // Memory
    static string userName = "";
    static string userInterest = "";

    // Keyword responses
    static Dictionary<string, string> keywordResponses = new Dictionary<string, string>()
    {
        { "password", "Cyber Eye: Password tips:\n- Use long, complex passwords.\n- Avoid using personal info.\n- Change them regularly." },
        { "scam", "Cyber Eye: Scams often pretend to be official messages. Never share info without verifying." },
        { "privacy", "Cyber Eye: Protect your privacy by adjusting your app and browser settings." },
        { "phishing", "Cyber Eye: Phishing is when attackers pretend to be trusted sources to steal your info." }
    };

    // Phishing prevention tips
    static List<string> phishingTips = new List<string>()
    {
        "Avoid clicking links in suspicious emails.",
        "Check the sender's email address carefully.",
        "Don't download unknown attachments.",
        "Use antivirus and enable spam filters."
    };

    static void Main()
    {
        PlayVoiceGreeting();
        DisplayAsciiLogo();

        Console.WriteLine("Welcome to Cyber Eye - Your Cybersecurity Awareness Bot!");
        Console.Write("Please enter your name: ");
        userName = Console.ReadLine();
        Console.WriteLine($"\nHello {userName}, I'm here to help you stay safe online!\n");

        StartChatbot();
    }

    static void PlayVoiceGreeting()
    {
        try
        {
            string filePath = @"C:\Users\RC_Student_lab\source\repos\CyberEyeChatbot\CyberEyeChatbot\CyberEyeChatbot\bin\Debug\greeting.wav";
            if (System.IO.File.Exists(filePath))
            {
                SoundPlayer player = new SoundPlayer(filePath);
                player.PlaySync();
            }
            else
            {
                Console.WriteLine("Error: WAV file not found. Please check the file location.");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error playing audio: {ex.Message}");
        }
    }

    static void DisplayAsciiLogo()
    {
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine(@"
         ██████╗██╗   ██╗███████╗███████╗
        ██╔════╝██║   ██║██╔════╝██╔════╝
        ██║     ██║   ██║█████╗  ███████╗
        ██║     ██║   ██║██╔══╝  ╚════██║
        ╚██████╗╚██████╔╝███████╗███████║
         ╚═════╝ ╚═════╝ ╚══════╝╚══════╝
         Cyber Eye - Protecting You Online!
        ");
        Console.ResetColor();
    }

    static void StartChatbot()
    {
        while (true)
        {
            Console.Write("\nYou: ");
            string userInput = Console.ReadLine().ToLower();

            if (string.IsNullOrWhiteSpace(userInput))
            {
                TypingEffect("Cyber Eye: Please enter a valid question.");
                continue;
            }

            if (userInput == "exit")
            {
                TypingEffect($"Cyber Eye: Stay safe online, {userName}! 👋");
                break;
            }

            // Sentiment detection
            if (userInput.Contains("worried") || userInput.Contains("scared"))
            {
                TypingEffect("Cyber Eye: It’s okay to feel that way. I'm here to help you stay protected.");
                continue;
            }

            if (userInput.Contains("curious"))
            {
                TypingEffect("Cyber Eye: I love your curiosity! Cybersecurity is an important skill to learn.");
                continue;
            }

            // Memory - Save interest
            if (userInput.Contains("interested in"))
            {
                int index = userInput.IndexOf("interested in");
                userInterest = userInput.Substring(index + 13).Trim();
                TypingEffect($"Cyber Eye: Noted! I'll remember you're interested in {userInterest}.");
                continue;
            }

            // Memory - Recall
            if (userInput.Contains("what do you remember"))
            {
                if (!string.IsNullOrEmpty(userInterest))
                    TypingEffect($"Cyber Eye: You said you're interested in {userInterest}. Want to know more?");
                else
                    TypingEffect("Cyber Eye: I don't remember anything yet. Tell me what you're interested in.");
                continue;
            }

            // Keyword-based response
            bool found = false;
            foreach (var keyword in keywordResponses)
            {
                if (userInput.Contains(keyword.Key))
                {
                    TypingEffect(keyword.Value);
                    found = true;
                    break;
                }
            }

            if (found) continue;

            // Specific phishing question
            if (userInput.Contains("how can i prevent phishing"))
            {
                Random rand = new Random();
                string tip = phishingTips[rand.Next(phishingTips.Count)];
                TypingEffect($"Cyber Eye: One tip is - {tip}");
                continue;
            }

            // Custom chat examples
            switch (userInput)
            {
                case "what is phishing":
                    TypingEffect("Cyber Eye: Phishing is a type of scam where attackers trick you into revealing personal info by pretending to be a trusted source.");
                    break;

                case "how are you":
                    TypingEffect("Cyber Eye: I'm just a chatbot, but always ready to help you stay safe!");
                    break;

                case "what's your purpose":
                    TypingEffect("Cyber Eye: My purpose is to guide and educate you about cybersecurity.");
                    break;

                case "what can i ask you about":
                    TypingEffect("Cyber Eye: Ask me about phishing, passwords, online scams, privacy, or anything cyber-related!");
                    break;

                default:
                    TypingEffect("Cyber Eye: I'm not sure I understand. Try asking about cyber safety topics.");
                    break;
            }
        }
    }

    static void TypingEffect(string message)
    {
        foreach (char c in message)
        {
            Console.Write(c);
            Thread.Sleep(30);
        }
        Console.WriteLine();
    }
}
